#!/usr/bin/env python3
"""
Boilerplate controller for the HE bot.

Fetches a shape from the get_shape service and builds a list of waypoints
to trace it. Fill in the control loop to drive the robot through them.


"""

import argparse
import math

import numpy as np
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64MultiArray
from shape_interface.srv import GetShape

# Wheel <-> body-velocity mapping, columns are [left, right, back] wheel
# speed (rad/s); rows are body frame [vx, vy, wz] per unit wheel speed.
_WHEEL_TO_BODY = np.array([
    [0.0255 / np.sqrt(3), -0.0255 / np.sqrt(3), 0.0],
    [0.0255 / 3.0, 0.0255 / 3.0, -0.051 / 3.0],
    [0.0255 / (3.0 * 0.06412), 0.0255 / (3.0 * 0.06412), 0.0255 / (3.0 * 0.06412)],
])
_BODY_TO_WHEEL = np.linalg.inv(_WHEEL_TO_BODY)
_CTRL_LIMIT = 30.0     # rad/s, matches lekiwi.xml actuator ctrlrange

WAYPOINT_TOLERANCE = 0.03  # metres
CIRCLE_SEGMENTS     = 36
POSITION_KP         = 2.0
YAW_HOLD_KP         = 2.5
CONTROL_PERIOD      = 0.02  # 50 Hz

def body_to_wheels(vx, vy, wz):
    """Body-frame (vx, vy, wz) -> wheel angular velocities [left, right, back]."""
    v_body = np.array([vx, vy, wz], dtype=float)
    wheels = _BODY_TO_WHEEL @ v_body
    wheels = np.clip(wheels, -_CTRL_LIMIT, _CTRL_LIMIT)
    return [float(x) for x in wheels]


def yaw_from_quat(w, x, y, z):
    """Convert quaternion (w, x, y, z) to yaw in radians."""
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    return math.atan2(siny_cosp, cosy_cosp)


def _regular_polygon(cx, cy, n_sides, side_length, start_angle=math.pi / 2):
    """Vertices of a regular polygon centred on (cx, cy), closed back to the
    first vertex so the last waypoint returns the robot to where it started
    drawing."""
    r = side_length / (2 * math.sin(math.pi / n_sides))
    pts = [
        (cx + r * math.cos(start_angle + 2 * math.pi * i / n_sides),
         cy + r * math.sin(start_angle + 2 * math.pi * i / n_sides))
        for i in range(n_sides)
    ]
    return pts + [pts[0]]


def build_waypoints(shape_name, data):
    """World-frame waypoints for `shape_name`, as returned by the get_shape
    service: data[0:2] is the shape's centre (x, y); the remaining entries
    are its size parameters (see shape_service.cpp's shape_map)."""
    cx, cy = data[0], data[1]

    if shape_name == "Circle":
        radius = data[2]
        return [
            (cx + radius * math.cos(2 * math.pi * i / CIRCLE_SEGMENTS),
             cy + radius * math.sin(2 * math.pi * i / CIRCLE_SEGMENTS))
            for i in range(1, CIRCLE_SEGMENTS + 1)
        ]

    if shape_name == "Square":
        return _regular_polygon(cx, cy, 4, data[2], start_angle=math.pi / 4)

    if shape_name == "Triangle":
        return _regular_polygon(cx, cy, 3, data[2])

    if shape_name == "Pentagon":
        return _regular_polygon(cx, cy, 5, data[2])

    if shape_name == "Rectangle":
        w, h = data[2], data[3]
        corners = [
            (cx - w / 2, cy - h / 2),
            (cx + w / 2, cy - h / 2),
            (cx + w / 2, cy + h / 2),
            (cx - w / 2, cy + h / 2),
        ]
        return corners + [corners[0]]

    raise ValueError(f"unknown shape '{shape_name}'")


class ShapeController(Node):
    def __init__(self, speed):
        super().__init__("shape_controller")
        self.speed = speed

        self.pose = None        # (x, y, yaw), latest ground truth
        self.start_pose = None  # (x, y, yaw), recorded on first odom message
        self.wp_index = 0
        self.done = False
        self.cmd_pub = self.create_publisher(Float64MultiArray, "/wheel_commands", 10)
        self.odom_sub = self.create_subscription(Odometry, "/odom", self._odom_cb, 10)

        self.shape_name, self.waypoints = self._request_shape()
        self.get_logger().info(f"Shape: {self.shape_name}, total waypoints: {len(self.waypoints)}")

        self.timer = self.create_timer(CONTROL_PERIOD, self._control_step)
    
    def _request_shape(self):
        client = self.create_client(GetShape, "get_shape")
        while not client.wait_for_service(timeout_sec=2.0):
            self.get_logger().info("Waiting for get_shape service...")

        future = client.call_async(GetShape.Request())
        rclpy.spin_until_future_complete(self, future)
        response = future.result()
        if response is None or not response.success:
            raise RuntimeError(
                f"get_shape service call failed: {response and response.message}"
            )

        return response.shape_name, build_waypoints(response.shape_name, list(response.data))

    def _odom_cb(self, msg):
        pos = msg.pose.pose.position
        orient = msg.pose.pose.orientation
        yaw = yaw_from_quat(orient.w, orient.x, orient.y, orient.z)
        self.pose = (pos.x, pos.y, yaw)
        if self.start_pose is None:
            self.start_pose = (pos.x, pos.y, yaw)
            self.get_logger().info(f"Initial odom pose: x={pos.x:.3f}, y={pos.y:.3f}, yaw={yaw:.3f}")

    def _publish(self, wheels):
        self.cmd_pub.publish(Float64MultiArray(data=wheels))

    def _control_step(self):
        if self.done or self.pose is None:
            return

        curr_x, curr_y, curr_yaw = self.pose
        target_x, target_y = self.waypoints[self.wp_index]

        dx = target_x - curr_x
        dy = target_y - curr_y
        dist = math.hypot(dx, dy)

        if dist < WAYPOINT_TOLERANCE:
            self.wp_index += 1
            if self.wp_index >= len(self.waypoints):
                self.done = True
                self._publish([0.0, 0.0, 0.0])
                self.get_logger().info(f"Finished tracing {self.shape_name}!")
                return
            target_x, target_y = self.waypoints[self.wp_index]
            dx = target_x - curr_x
            dy = target_y - curr_y
            dist = math.hypot(dx, dy)

        # Proportional position control in world frame
        vx_world = POSITION_KP * dx
        vy_world = POSITION_KP * dy

        # Saturate translational speed to self.speed
        v_mag = math.hypot(vx_world, vy_world)
        if v_mag > self.speed:
            vx_world = (vx_world / v_mag) * self.speed
            vy_world = (vy_world / v_mag) * self.speed

        # Transform world velocities to robot body frame
        cos_yaw = math.cos(curr_yaw)
        sin_yaw = math.sin(curr_yaw)
        vx_body = vx_world * cos_yaw + vy_world * sin_yaw
        vy_body = -vx_world * sin_yaw + vy_world * cos_yaw

        # Heading hold (keep yaw aligned with starting yaw)
        target_yaw = self.start_pose[2]
        yaw_err = (target_yaw - curr_yaw + math.pi) % (2.0 * math.pi) - math.pi
        wz = YAW_HOLD_KP * yaw_err

        wheels = body_to_wheels(vx_body, vy_body, wz)
        self._publish(wheels)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--speed", type=float, default=0.25,
                         help="max approach speed, m/s")
    args, ros_args = parser.parse_known_args()

    rclpy.init(args=ros_args)
    node = ShapeController(args.speed)
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
        pass
    finally:
        node._publish([0.0, 0.0, 0.0])
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()

